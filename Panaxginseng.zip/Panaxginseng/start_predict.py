import os
import shutil
from model import build_model
from keras.backend.tensorflow_backend import set_session
from Predict import Predict
import tensorflow as tf
import numpy as np
from mk_camera import thread


config = tf.ConfigProto()
config.gpu_options.per_process_gpu_memory_fraction = 0.1
set_session(tf.Session(config=config))


def rebuild():
    # 初始化模型
    model = build_model()
    print('test model...')
    # 根据自己传入图片格式定义np.zeros（）
    print(model.predict(np.zeros((1, 60, 80, 3))))
    print('test done.')
    return model


def load_file(path):
    # 图片所在文件夹
    # path = '/home/gszn/test/rename/'
    # 创建六个文件夹，模拟六个摄像头
    path1 = path + '1/'
    path2 = path + '2/'
    path3 = path + '3/'
    path4 = path + '4/'
    path5 = path + '5/'
    path6 = path + '6/'
    file_list_a = os.listdir(path)
    # print(file_list)
    if not os.path.exists(path1):
        os.mkdir(path1)
    if not os.path.exists(path2):
        os.mkdir(path2)
    if not os.path.exists(path3):
        os.mkdir(path3)
    if not os.path.exists(path4):
        os.mkdir(path4)
    if not os.path.exists(path5):
        os.mkdir(path5)
    if not os.path.exists(path6):
        os.mkdir(path6)

    path_list = [path1, path2, path3, path4, path5, path6]
    return file_list_a, path_list


# 将文件夹内图片分发给六个文件夹
def send_file(file_list, path_list, path):
    try:
        for i in range(len(file_list)):
            filename1 = file_list[i].split('.')[-1]
            # 读取文件后缀名
            if filename1 == 'jpg':
                shutil.copy(path + file_list[i], path_list[i % 6] + file_list[i])
            else:
                continue
    except FileNotFoundError:
        print("ERROR")


def save_file(ppath):
    # 输入文件存储路径
    # ppath = input('请输入您想要存储图片的路径：    ')
    if not os.path.exists(ppath):
        os.mkdir(ppath)
    # 在存储路径下创建三个分类文件夹
    big_file = ppath + '/' + 'big_file/'
    middle_file = ppath + '/' + 'middle_file/'
    small_file = ppath + '/' + 'small_file/'
    if not os.path.exists(big_file):
        os.mkdir(big_file)
    if not os.path.exists(middle_file):
        os.mkdir(middle_file)
    if not os.path.exists(small_file):
        os.mkdir(small_file)
    file_list = [big_file, middle_file, small_file]

    return file_list


def start_predict(path_list, file_list):
    # 六个线程进行分类
    model = rebuild()
    image_list = thread()

    pred1 = Predict(model, image_list[0], file_list[0], file_list[1], file_list[2])
    pred2 = Predict(model, image_list[1], file_list[0], file_list[1], file_list[2])
    pred3 = Predict(model, image_list[2], file_list[0], file_list[1], file_list[2])
    pred4 = Predict(model, image_list[3], file_list[0], file_list[1], file_list[2])
    pred5 = Predict(model, image_list[4], file_list[0], file_list[1], file_list[2])
    pred6 = Predict(model, image_list[5], file_list[0], file_list[1], file_list[2])
    big_list = []
    middle_list = []
    small_list = []

    c1, name1 = pred1.predict()

    if c1 == 0:
        big_list.append(name1)
    if c1 == 1:
        middle_list.append(name1)
    if c1 == 2:
        small_list.append(name1)

    c2, name2 = pred2.predict()

    if c2 == 0:
        big_list.append(name2)
    if c2 == 1:
        middle_list.append(name2)
    if c2 == 2:
        small_list.append(name2)

    c3, name3 = pred3.predict()

    if c3 == 0:
        big_list.append(name3)
    if c3 == 1:
        middle_list.append(name3)
    if c3 == 2:
        small_list.append(name3)

    c4, name4 = pred4.predict()
    if c4 == 0:
        big_list.append(name4)
    if c4 == 1:
        middle_list.append(name4)
    if c4 == 2:
        small_list.append(name4)

    c5, name5 = pred5.predict()
    if c5 == 0:
        big_list.append(name5)
    if c5 == 1:
        middle_list.append(name5)
    if c5 == 2:
        small_list.append(name5)

    c6, name6 = pred6.predict()
    if c6 == 0:
        big_list.append(name6)
    if c6 == 1:
        middle_list.append(name6)
    if c6 == 2:
        small_list.append(name6)

    return image_list, big_list, middle_list, small_list






