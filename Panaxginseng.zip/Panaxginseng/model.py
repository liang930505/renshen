from keras.layers import Dense, Flatten
from keras.layers.convolutional import Conv2D, MaxPooling2D
import os
from keras import Sequential


def build_model():
    # 网络结构：四层卷积层、三层池化层、两层全连接层
    model = Sequential()
    model.add(Conv2D(8, (3, 3), strides=(1, 1), input_shape=(60, 80, 3), padding='same', activation='relu',
                     kernel_initializer='uniform'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Conv2D(16, (3, 2), strides=(1, 1), padding='same', activation='relu', kernel_initializer='uniform'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Conv2D(32, (3, 3), strides=(1, 1), padding='same', activation='relu', kernel_initializer='uniform'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Conv2D(32, (3, 3), strides=(1, 1), padding='same', activation='relu', kernel_initializer='uniform'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Flatten())
    model.add(Dense(24, activation='relu'))
    # model.add(Dropout(0.5))
    model.add(Dense(24, activation='relu'))
    # model.add(Dropout(0.5))
    model.add(Dense(3, activation='softmax'))
    if os.path.exists('logsep175-loss0.027-val_loss0.069.h5'):
        model.load_weights('logsep175-loss0.027-val_loss0.069.h5')
    else:
        print('cant open model_weight file')
    return model
