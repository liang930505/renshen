# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Panaxginseng.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!
import sys
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtGui import QPixmap


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(1980, 1000)

        self.label_7 = QtWidgets.QLabel(Dialog)
        self.label_7.setGeometry(QtCore.QRect(1300, 400, 54, 12))
        self.label_7.setObjectName("label_7")

        self.label_8 = QtWidgets.QLabel(Dialog)
        self.label_8.setGeometry(QtCore.QRect(1300, 558, 54, 12))
        self.label_8.setObjectName("label_8")

        self.label_9 = QtWidgets.QLabel(Dialog)
        self.label_9.setGeometry(QtCore.QRect(1300, 720, 54, 12))
        self.label_9.setObjectName("label_9")

        self.label_10 = QtWidgets.QLabel(Dialog)
        self.label_10.setGeometry(QtCore.QRect(1400, 400, 54, 12))
        self.label_10.setObjectName("label_10")

        self.label_11 = QtWidgets.QLabel(Dialog)
        self.label_11.setGeometry(QtCore.QRect(1400, 550, 54, 20))
        self.label_11.setObjectName("label_11")

        self.label_12 = QtWidgets.QLabel(Dialog)
        self.label_12.setGeometry(QtCore.QRect(1400, 720, 54, 12))
        self.label_12.setObjectName("label_12")
        # LCD
        self.lcdNumber = QtWidgets.QLCDNumber(Dialog)
        self.lcdNumber.setGeometry(QtCore.QRect(1600, 100, 300, 40))
        self.lcdNumber.setObjectName("lcdNumber")
        # 尺寸图片
        self.label_13 = QtWidgets.QLabel(Dialog)
        self.label_13.setGeometry(QtCore.QRect(1550, 350, 120, 90))
        self.label_13.setObjectName("label_13")

        self.label_14 = QtWidgets.QLabel(Dialog)
        self.label_14.setGeometry(QtCore.QRect(1550, 500, 120, 90))
        self.label_14.setObjectName("label_14")

        self.label_15 = QtWidgets.QLabel(Dialog)
        self.label_15.setGeometry(QtCore.QRect(1550, 650, 120, 90))
        self.label_15.setObjectName("label_15")
        # 模式按钮
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(300, 850, 200, 40))
        self.pushButton.setObjectName("pushButton")

        self.pushButton_2 = QtWidgets.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(600, 850, 200, 40))
        self.pushButton_2.setObjectName("pushButton_2")

        self.pushButton_3 = QtWidgets.QPushButton(Dialog)
        self.pushButton_3.setGeometry(QtCore.QRect(900, 850, 200, 40))
        self.pushButton_3.setObjectName("pushButton_3")

        self.pushButton_4 = QtWidgets.QPushButton(Dialog)
        self.pushButton_4.setGeometry(QtCore.QRect(1200, 850, 200, 40))
        self.pushButton_4.setObjectName("pushButton_4")
        # 分割线
        self.line = QtWidgets.QFrame(Dialog)
        self.line.setGeometry(QtCore.QRect(1200, 0, 20, 800))
        self.line.setFrameShape(QtWidgets.QFrame.VLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        # 分割线
        self.line_2 = QtWidgets.QFrame(Dialog)
        self.line_2.setGeometry(QtCore.QRect(0, 800, 2361, 20))
        self.line_2.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_2.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_2.setObjectName("line_2")
        # 分割线
        self.line_3 = QtWidgets.QFrame(Dialog)
        self.line_3.setGeometry(QtCore.QRect(0, 900, 2261, 16))
        self.line_3.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_3.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_3.setObjectName("line_3")
        # 确认按钮
        self.pushButton_5 = QtWidgets.QPushButton(Dialog)
        self.pushButton_5.setGeometry(QtCore.QRect(600, 950, 200, 40))
        self.pushButton_5.setObjectName("pushButton_5")


        self.pushButton_6 = QtWidgets.QPushButton(Dialog)
        self.pushButton_6.setGeometry(QtCore.QRect(900, 950, 200, 40))
        self.pushButton_6.setObjectName("pushButton_6")

        self.widget = QtWidgets.QWidget(Dialog)
        self.widget.setGeometry(QtCore.QRect(20, 20, 1371, 821))
        self.widget.setObjectName("widget")
        # 摄像机图片
        self.label = QtWidgets.QLabel(self.widget)
        self.label.setGeometry(QtCore.QRect(50, 120, 240, 180))
        self.label.setObjectName("label")

        self.label_2 = QtWidgets.QLabel(self.widget)
        self.label_2.setGeometry(QtCore.QRect(450, 120, 240, 180))
        self.label_2.setObjectName("label_2")

        self.label_3 = QtWidgets.QLabel(self.widget)
        self.label_3.setGeometry(QtCore.QRect(850, 120, 240, 180))
        self.label_3.setObjectName("label_3")

        self.label_4 = QtWidgets.QLabel(self.widget)
        self.label_4.setGeometry(QtCore.QRect(50, 450, 240, 180))
        self.label_4.setObjectName("label_4")

        self.label_5 = QtWidgets.QLabel(self.widget)
        self.label_5.setGeometry(QtCore.QRect(450, 450, 240, 180))
        self.label_5.setObjectName("label_5")

        self.label_6 = QtWidgets.QLabel(self.widget)
        self.label_6.setGeometry(QtCore.QRect(850, 450, 240, 180))
        self.label_6.setObjectName("label_6")
        # 摄像机位置
        self.label_16 = QtWidgets.QLabel(self.widget)
        self.label_16.setGeometry(QtCore.QRect(70, 70, 200, 40))
        font = QtGui.QFont()
        font.setFamily("微软雅黑")
        font.setPointSize(22)
        self.label_16.setFont(font)
        self.label_16.setContextMenuPolicy(QtCore.Qt.NoContextMenu)
        self.label_16.setAlignment(QtCore.Qt.AlignCenter)
        self.label_16.setObjectName("label_16")

        self.label_17 = QtWidgets.QLabel(self.widget)
        self.label_17.setGeometry(QtCore.QRect(470, 70, 200, 40))
        font = QtGui.QFont()
        font.setFamily("微软雅黑")
        font.setPointSize(22)
        self.label_17.setFont(font)
        self.label_17.setContextMenuPolicy(QtCore.Qt.NoContextMenu)
        self.label_17.setAlignment(QtCore.Qt.AlignCenter)
        self.label_17.setObjectName("label_17")

        self.label_18 = QtWidgets.QLabel(self.widget)
        self.label_18.setGeometry(QtCore.QRect(870, 70, 200, 40))
        font = QtGui.QFont()
        font.setFamily("微软雅黑")
        font.setPointSize(22)
        self.label_18.setFont(font)
        self.label_18.setContextMenuPolicy(QtCore.Qt.NoContextMenu)
        self.label_18.setAlignment(QtCore.Qt.AlignCenter)
        self.label_18.setObjectName("label_18")

        self.label_19 = QtWidgets.QLabel(self.widget)
        self.label_19.setGeometry(QtCore.QRect(70, 400, 200, 40))
        font = QtGui.QFont()
        font.setFamily("微软雅黑")
        font.setPointSize(22)
        self.label_19.setFont(font)
        self.label_19.setContextMenuPolicy(QtCore.Qt.NoContextMenu)
        self.label_19.setAlignment(QtCore.Qt.AlignCenter)
        self.label_19.setObjectName("label_19")

        self.label_20 = QtWidgets.QLabel(self.widget)
        self.label_20.setGeometry(QtCore.QRect(470, 400, 200, 40))
        font = QtGui.QFont()
        font.setFamily("微软雅黑")
        font.setPointSize(22)
        self.label_20.setFont(font)
        self.label_20.setContextMenuPolicy(QtCore.Qt.NoContextMenu)
        self.label_20.setAlignment(QtCore.Qt.AlignCenter)
        self.label_20.setObjectName("label_20")

        self.label_21 = QtWidgets.QLabel(self.widget)
        self.label_21.setGeometry(QtCore.QRect(870, 400, 200, 40))
        font = QtGui.QFont()
        font.setFamily("微软雅黑")
        font.setPointSize(22)
        self.label_21.setFont(font)
        self.label_21.setContextMenuPolicy(QtCore.Qt.NoContextMenu)
        self.label_21.setAlignment(QtCore.Qt.AlignCenter)
        self.label_21.setObjectName("label_21")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))

        # 属性函数
        self.label_7.setText(_translate("Dialog", "大"))
        self.label_8.setText(_translate("Dialog", "中"))
        self.label_9.setText(_translate("Dialog", "小"))
        #  数量
        # self.label_10.setText(_translate("Dialog", "TextLabel"))
        # self.label_11.setText(_translate("Dialog", "TextLabel"))
        # self.label_12.setText(_translate("Dialog", "TextLabel"))

        # 分类图片
        # self.label_13.setText(_translate("Dialog", "TextLabel"))
        # self.label_14.setText(_translate("Dialog", "TextLabel"))
        # self.label_15.setText(_translate("Dialog", "TextLabel"))

        # 按钮
        # self.pushButton.setText(_translate("Dialog", "PushButton"))
        self.pushButton_2.setText(_translate("Dialog", "PushButton"))
        self.pushButton_3.setText(_translate("Dialog", "PushButton"))
        self.pushButton_4.setText(_translate("Dialog", "PushButton"))
        self.pushButton_5.setText(_translate("Dialog", "确定"))
        self.pushButton_6.setText(_translate("Dialog", "退出"))
        # 摄像机拍照图
        # self.label.setText(_translate("Dialog", "IMG1"))
        # self.label_2.setText(_translate("Dialog", "IMG2"))
        # self.label_3.setText(_translate("Dialog", "IMG3"))
        # self.label_4.setText(_translate("Dialog", "IMG4"))
        # self.label_5.setText(_translate("Dialog", "IMG5"))
        # self.label_6.setText(_translate("Dialog", "IMG6"))
        # 摄像机位置
        self.label_16.setText(_translate("Dialog", "摄像机1"))
        self.label_17.setText(_translate("Dialog", "摄像机2"))
        self.label_18.setText(_translate("Dialog", "摄像机3"))
        self.label_19.setText(_translate("Dialog", "摄像机4"))
        self.label_20.setText(_translate("Dialog", "摄像机5"))
        self.label_21.setText(_translate("Dialog", "摄像机6"))
