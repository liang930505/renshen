from time import ctime
import threading
import os
import random
import cv2

class MyThread(threading.Thread):
    def __init__(self, func, args):
        threading.Thread.__init__(self)
        self.func = func
        self.args = args
        try:
            self.img, self.path, self.name = self.func(self.args)
        except TypeError:
            pass
    def get_result(self):
        try:
            return self.path + self.name
        except Exception as e:
            return None


def get_image(path):
    file_list = os.listdir(path)
    random.shuffle(file_list)
    try:
        img = cv2.imread(path + file_list[0])
        return img, path, file_list[0]
    except IndexError:
        pass


def thread():
    print('start at', ctime())
    threads = []

    path = '/home/gszn/test/rename/'
    path1 = path + '1/'
    path2 = path + '2/'
    path3 = path + '3/'
    path4 = path + '4/'
    path5 = path + '5/'
    path6 = path + '6/'
    path_list = [path1, path2, path3, path4, path5, path6]
    image_list = []
    for i in range(6):
        t = MyThread(get_image, path_list[i])
        print(t)
        threads.append(t)
    for i in range(6):  # start threads 此处并不会执行线程，而是将任务分发到每个线程，同步线程。等同步完成后再开始执行start方法
        threads[i].start()
    for i in range(6):  # jion()方法等待线程完成
        threads[i].join()

        image_list.append(threads[i].get_result())
    return image_list

