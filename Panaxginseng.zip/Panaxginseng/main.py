# -*- coding: utf-8 -*-
# @Author: PoisonCracker
# @Date:   2018-12-26 17:07:03
# @Last Modified by:   Administrator
# @Last Modified time: 2018-12-27 14:09:03
#
# import predict
from GUI import Ui_Dialog
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *
import sys
import os
from mk_camera import thread
# import start_p
# from retry import retry
from logging.handlers import TimedRotatingFileHandler
import logging

from start_predict import load_file, save_file, start_predict, send_file

ROOTPATH = "."
logfile = os.sep.join([ROOTPATH, 'renshen.log'])
print("日志路径%s" % logfile)
# 初始化日志系统
logging.basicConfig(level=logging.INFO, datefmt=None,
                    format='%(asctime)-24s level-%(levelname)-12s thread-%(thread)-6d %(module)-s.%(funcName)-10s Line:%(lineno)-4d %(message)s',
                    handlers=[logging.StreamHandler(), TimedRotatingFileHandler(logfile, when='D', interval=1, backupCount=15)])

LOG=logging.getLogger()
LOG.handlers[0].setLevel(logging.WARN)
LOG.handlers[1].setLevel(logging.INFO)

class Set_IMG(Ui_Dialog):  # 继承UI_Dialog
    def __init__(self):
        super(Set_IMG, self).__init__()
        self.directory = self.msg()

    def set_read_img(self, Dialog, CAMERA1, CAMERA2, CAMERA3, CAMERA4, CAMERA5, CAMERA6):
        # 读取摄像头图片
        # 摄像头1
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setToolTip('CAMERA1')
        self.label.setScaledContents(True)
        self.label.setStyleSheet("border: 2px solid red")
        self.label.setPixmap(QtGui.QPixmap(CAMERA1))
        # 摄像头2
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setToolTip('CAMERA2')
        self.label_2.setScaledContents(True)
        self.label_2.setStyleSheet("border: 2px solid red")
        self.label_2.setPixmap(QtGui.QPixmap(CAMERA2))
        # 摄像头3
        self.label_3.setAlignment(QtCore.Qt.AlignCenter)
        self.label_3.setToolTip('CAMERA3')
        self.label_3.setScaledContents(True)
        self.label_3.setStyleSheet("border: 2px solid red")
        self.label_3.setPixmap(QtGui.QPixmap(CAMERA3))
        # 摄像头4
        self.label_4.setAlignment(QtCore.Qt.AlignCenter)
        self.label_4.setToolTip('CAMERA4')
        self.label_4.setScaledContents(True)
        self.label_4.setStyleSheet("border: 2px solid red")
        self.label_4.setPixmap(QtGui.QPixmap(CAMERA4))
        # 摄像头5
        self.label_5.setAlignment(QtCore.Qt.AlignCenter)
        self.label_5.setToolTip('CAMERA5')
        self.label_5.setScaledContents(True)
        self.label_5.setStyleSheet("border: 2px solid red")
        self.label_5.setPixmap(QtGui.QPixmap(CAMERA5))
        # 摄像头6
        self.label_6.setAlignment(QtCore.Qt.AlignCenter)
        self.label_6.setToolTip('CAMERA6')
        self.label_6.setScaledContents(True)
        self.label_6.setStyleSheet("border: 2px solid red")
        self.label_6.setPixmap(QtGui.QPixmap(CAMERA6))

    def classify_img(self, Dialog, BIG_IMG, MIDDLE_IMG, SMALL_IMG):
        # 大
        self.label_13.setAlignment(QtCore.Qt.AlignCenter)
        self.label_13.setToolTip('BIG_IMG')
        self.label_13.setScaledContents(True)
        self.label_13.setStyleSheet("border: 2px solid red")
        self.label_13.setPixmap(QtGui.QPixmap(BIG_IMG))
        # 中
        self.label_14.setAlignment(QtCore.Qt.AlignCenter)
        self.label_14.setToolTip('MIDDLE_IMG')
        self.label_14.setScaledContents(True)
        self.label_14.setStyleSheet("border: 2px solid red")
        self.label_14.setPixmap(QtGui.QPixmap(MIDDLE_IMG))
        # 小
        self.label_15.setAlignment(QtCore.Qt.AlignCenter)
        self.label_15.setToolTip('SMALL_IMG')
        self.label_15.setScaledContents(True)
        self.label_15.setStyleSheet("border: 2px solid red")
        self.label_15.setPixmap(QtGui.QPixmap(SMALL_IMG))

    def LCD_Display(self, number):
        self.lcdNumber.display(number)

    def Label_Num(self,num1,num2,num3):
        self.label_10.setText(str(num1))
        self.label_11.setText(str(num2))
        self.label_12.setText(str(num3))

    def clicked(self, Dialog):
        # 鼠标点击函数
        self.pushButton.setText("选择文件夹")
        self.pushButton.clicked.connect(self.msg)

        self.pushButton_5.clicked.connect(self.action)
        self.pushButton_5.setAutoRepeat(True)

        self.pushButton_6.clicked.connect(QtCore.QCoreApplication.quit)

    def action(self):  # 显示摄像头处理动作

        path = '/home/gszn/test/rename/'
        file_list, path_list = load_file(path)

        send_file(file_list, path_list, path)
        file_list1 = save_file(self.directory)

        image_list, big, middle, small = start_predict(path_list, file_list1)

        ui.set_read_img(MainWindow, image_list[0], image_list[1], image_list[2], image_list[3], image_list[4],
                        image_list[5])
        if len(big) == 0:
            ui.classify_img(MainWindow, None, file_list1[1] + middle[0], file_list1[2] + small[0])
        if len(middle) == 0:
            ui.classify_img(MainWindow, file_list1[0] + big[0], None, file_list1[2] + small[0])
        if len(small) == 0:
            ui.classify_img(MainWindow, file_list1[0] + big[0], file_list1[1] + middle[0], None)
        else:
            ui.classify_img(MainWindow, file_list1[0] + big[0], file_list1[1] + middle[0], file_list1[2] + small[0])
        a = len(os.listdir(file_list1[0])) + len(os.listdir(file_list1[1])) + len(os.listdir(file_list1[2]))
        self.LCD_Display(a)
        big_num = len(big)
        middle_num = len(middle)
        small_num = len(small)

        self.Label_Num(big_num, middle_num, small_num)

    def msg(self):  # 按钮1保存路径函数r

        directory = QFileDialog.getExistingDirectory(parent=None,
                                                     caption="选取文件夹",
                                                     directory="/home/gszn/la/",
                                                     options=QFileDialog.ShowDirsOnly)  # 起始路径

        return directory


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Set_IMG()
    ui.setupUi(MainWindow)
    ui.clicked(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
