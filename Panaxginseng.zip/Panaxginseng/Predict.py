import numpy as np
import tensorflow as tf
import keras.backend.tensorflow_backend as KTF
import shutil
import os
import cv2


KTF.set_session(tf.Session(config=tf.ConfigProto(device_count={'gpu': 0})))


class Predict:

    def __init__(self, model, image, big_file, middle_file, small_file):

        self.model = model
        self.image = image
        self.big_file = big_file
        self.middle_file = middle_file
        self.small_file = small_file


    def img_read(self):

        try:
            img = cv2.imread(self.image)
            scaled_pic = cv2.resize(img, (80, 60), interpolation=cv2.INTER_CUBIC)
            pic = np.asarray(scaled_pic, dtype='float32')
            pic = pic / 255
            pic = np.expand_dims(pic, axis=0)
            return pic
        except cv2.error:
            pass
        except TypeError:
            print('empty')

    def predict(self):
        try:
            x_test = self.img_read()

            pred = self.model.predict(x_test)


            for j in range(len(pred)):
                # 数组转列表
                pred_list = pred[j].tolist()
                # 列表最大值索引
                c = pred_list.index(max(pred[j]))

                path, name = os.path.split(self.image)

                if c == 0:
                    if os.path.exists(self.big_file + name):
                        os.remove(self.big_file + name)
                        # 移动图像到所属类别文件夹
                        shutil.copy(path + '/' + name, self.big_file + name)
                        return c, name
                    else:
                        # print(self.big_file)
                        shutil.copy(path + '/' + name, self.big_file + name)
                        return c, name
                if c == 1:
                    if os.path.exists(self.middle_file + name):
                        os.remove(self.middle_file + name)
                        shutil.copy(path + '/' + name, self.middle_file + name)
                        return c, name
                    else:
                        # print(self.middle_file)
                        shutil.copy(path + '/' + name, self.middle_file + name)
                        return c, name
                if c == 2:
                    if os.path.exists(self.small_file + name):
                        os.remove(self.small_file + name)
                        shutil.copy(path + '/' + name, self.small_file + name)
                        return c, name
                    else:
                        shutil.copy(path + '/' + name, self.small_file + name)
                        return c, name
        except TypeError:
            pass

